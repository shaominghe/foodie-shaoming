create
    definer = root@localhost procedure pro_t1()
begin
declare i int;
set i=0;
while i<100000 do
    insert into  t1 (id,name)
    values (i,CONCAT('smartan',i));
set i=i+1;
end while;
end;

